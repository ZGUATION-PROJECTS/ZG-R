#!/bin/sh
# Copyright (C) 2025-2026 ukriu (Contact: contact@ukriu.com)
# Read LICENSE_NOTICE.txt for further info.

. ./utils.sh
CONFIG_FILE="$RESDIR/config"

usage() {
    cat <<EOF
Usage:
  sh webui.sh set <setting> <value>
  sh webui.sh extra_tiles all|custom (key)
  sh webui.sh apply
  sh webui.sh status
  sh webui.sh clear
  sh webui.sh soft_restart

Settings:
  blur true|false
  screenshot_blur true|false
  highend true|false
  leica true|false
  island true|false
  device_level v:1,c:1,g:1 .. v:1,c:3,g:3 (or default)
EOF
}

is_bool() {
    [ "$1" = "true" ] || [ "$1" = "false" ]
}

# clunky ass solution :cry:
is_device_level() {
    case "$1" in
        default|v:1,c:1,g:1|v:1,c:1,g:2|v:1,c:1,g:3|v:1,c:2,g:1|v:1,c:2,g:2|v:1,c:2,g:3|v:1,c:3,g:1|v:1,c:3,g:2|v:1,c:3,g:3)
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

set_config_entry() {
    key="$1"
    value="$2"

    mkdir -p "$RESDIR" || return 1
    touch "$CONFIG_FILE" || return 1

    tmp_file="${CONFIG_FILE}.tmp"
    awk -F'=' -v k="$key" -v v="$value" '
        BEGIN { updated = 0 }
        $1 == k { print k "=" v; updated = 1; next }
        { print }
        END { if (!updated) print k "=" v }
    ' "$CONFIG_FILE" > "$tmp_file" || return 1

    mv "$tmp_file" "$CONFIG_FILE" || return 1
    return 0
}

get_config_entry() {
    key="$1"
    default_value="$2"

    if [ ! -f "$CONFIG_FILE" ]; then
        echo "$default_value"
        return
    fi

    value="$(awk -F'=' -v k="$key" '$1==k{print substr($0, index($0, "=")+1)}' "$CONFIG_FILE" | tail -n 1)"
    if [ -n "$value" ]; then
        echo "$value"
    else
        echo "$default_value"
    fi
}

detect_current_island() {
    if [ -f "$MODDIR/system.prop" ] && grep -q "\$start_islandon" "$MODDIR/system.prop"; then
        echo "true"
    else
        echo "false"
    fi
}

detect_current_leica() {
    if [ -f "$MODDIR/system.prop" ] && grep -q "\$start_leica" "$MODDIR/system.prop"; then
        echo "true"
    else
        echo "false"
    fi
}

detect_current_blur() {
    if [ -f "$MODDIR/system.prop" ] && grep -q "\$start_bluroff" "$MODDIR/system.prop"; then
        echo "false"
    else
        echo "true"
    fi
}

detect_current_highend() {
    if [ -f "$MODDIR/system.prop" ] && grep -q "\$start_highend" "$MODDIR/system.prop"; then
        echo "true"
    else
        echo "false"
    fi
}

detect_current_ssblur() {
    if [ -f "$MODDIR/system/product/overlay/HyperUnlocked-screenshot-blur.apk" ]; then
        echo "true"
    else
        echo "false"
    fi
}

detect_current_device_level() {
    echo "$CUR_DEVICE_LEVEL_LIST"
}

set_device_level() {
    su -c "settings put system deviceLevelList $1"
}

read_module_prop() {
    key="$1"
    module_prop_path="$MODDIR/module.prop"

    if [ ! -f "$module_prop_path" ]; then
        return 1
    fi

    awk -F'=' -v k="$key" '$1==k{print substr($0, index($0, "=")+1); exit}' "$module_prop_path"
}

set_value_cmd() {
    setting="$1"
    value="$2"

    if [ -z "$setting" ] || [ -z "$value" ]; then
        usage
        return 1
    fi

    case "$setting" in
        blur|screenshot_blur|leica|highend|island)
            if ! is_bool "$value"; then
                warn "Invalid value '$value' for '$setting'. Use true/false."
                return 1
            fi
            staged_value="$value"
            ;;
        device_level)
            if ! is_device_level "$value"; then
                warn "Invalid device level '$value'."
                return 1
            fi
            staged_value="$value"
            ;;
        *)
            warn "Unknown setting '$setting'."
            usage
            return 1
            ;;
    esac

    if ! set_config_entry "$setting" "$staged_value"; then
        warn "Failed writing config file: $CONFIG_FILE"
        return 1
    fi

    log "Queued: $setting=$staged_value"
    return 0
}

apply_cmd() {
    if [ ! -f "$CONFIG_FILE" ] || [ ! -s "$CONFIG_FILE" ]; then
        log "No pending config found at $CONFIG_FILE"
        return 0
    fi

    current_level="$(detect_current_device_level)"
    current_blur="$(detect_current_blur)"
    current_highend="$(detect_current_highend)"
    current_ssblur="$(detect_current_ssblur)"
    current_leica="$(detect_current_leica)"
    current_island="$(detect_current_island)"
    island="$(get_config_entry island "$current_island")"
    if ! is_bool "$island"; then
        warn "Invalid staged island value."
        return 1
    fi
    leica="$(get_config_entry leica "$current_leica")"
    if ! is_bool "$leica"; then
        warn "Invalid staged leica value."
        return 1
    fi
    blur="$(get_config_entry blur "$current_blur")"
    if ! is_bool "$blur"; then
        warn "Invalid staged blur value."
        return 1
    fi
    highend="$(get_config_entry highend "$current_highend")"
    if ! is_bool "$highend"; then
        warn "Invalid staged highend value."
        return 1
    fi
    ssblur="$(get_config_entry screenshot_blur "$current_ssblur")"
    if ! is_bool "$ssblur"; then
        warn "Invalid staged screenshot_blur value."
        return 1
    fi
    device_level="$(get_config_entry device_level "$current_level")"
    if ! is_device_level "$device_level"; then
        warn "Invalid staged device_level value."
        return 1
    fi

    if [ "$blur" = "true" ]; then
        CHOICE_BLUR=true
        log "Blurs: enabled"
    else
        CHOICE_BLUR=false
        log "Blurs: disabled"
    fi

    if [ "$highend" = "true" ]; then
        CHOICE_HE=true
        log "High-end props: enabled"
    else
        CHOICE_HE=false
        log "High-end props: disabled"
    fi

    if [ "$device_level" = "default" ]; then
        restore_deviceLevelList
        log "Device level: restored default"
    else
        save_deviceLevelList
        if ! set_device_level "$device_level"; then
            warn "Failed to apply deviceLevelList '$device_level'."
            return 1
        fi
        log "Device level: $device_level"
    fi

    if [ "$leica" = "true" ]; then
        CHOICE_LEICA=true
        log "Leica Spoof: enabled"
    else
        CHOICE_LEICA=false
        log "Leica Spoof: disabled"
    fi

    if [ "$island" = "true" ]; then
        CHOICE_ISLAND=true
        log "Dynamic Island: enabled"
    else
        CHOICE_ISLAND=false
        log "Dynamic Island: disabled"
    fi

    if ! define_props; then
        warn "Failed generating system.prop."
        return 1
    fi

    if [ "$ssblur" = "true" ]; then
        add_ssblur
        log "Screenshot blur: enabled"
    else
        remove_ssblur
        log "Screenshot blur: disabled"
    fi

    update_desc
    warning

    rm -f "$CONFIG_FILE"
    log "Applied successfully."
    log "Applying props for this runtime session.."
    apply_props
    log "Do a Soft Reboot to see the prop changes!"
    log "A full reboot is still required for some changes."
    return 0
}

status_cmd() {
    module_version="$(read_module_prop version 2>/dev/null)"
    module_version_code="$(read_module_prop versionCode 2>/dev/null)"

    current_level="$(detect_current_device_level)"
    current_blur="$(detect_current_blur)"
    current_highend="$(detect_current_highend)"
    current_ssblur="$(detect_current_ssblur)"
    current_leica="$(detect_current_leica)"
    current_island="$(detect_current_island)"

    # coulf be that user running script outside the module maybe
    [ -n "$module_version" ] && echo "version=$module_version"
    [ -n "$module_version_code" ] && echo "versionCode=$module_version_code"
    echo "current.device_level=$current_level"
    echo "current.blur=$current_blur"
    echo "current.highend=$current_highend"
    echo "current.screenshot_blur=$current_ssblur"
    echo "current.leica=$current_leica"
    echo "current.island=$current_island"

    if [ -f "$CONFIG_FILE" ] && [ -s "$CONFIG_FILE" ]; then
        echo "pending.config=true"
        while IFS= read -r line; do
            [ -n "$line" ] && echo "pending.$line"
        done < "$CONFIG_FILE"
    else
        echo "pending.config=false"
    fi
}

clear_cmd() {
    if rm -f "$CONFIG_FILE"; then
        log "Cleared staged config."
        return 0
    fi

    warn "Failed clearing staged config."
    return 1
}

soft_restart_cmd() {
    packages="com.android.systemui com.miui.home com.xiaomi.misettings com.android.settings com.miui.securitycenter com.miui.powerkeeper com.android.camera"
    for pkg in $packages; do
        if killall "$pkg" 2>/dev/null; then
            log "Killed $pkg"
        else
            warn "$pkg not running"
        fi
    done
}

command="$1"
shift 2>/dev/null

case "$command" in
    set)
        set_value_cmd "$1" "$2"
        ;;
    extra_tiles)
        add_qs_tiles "$1" "$2"
        ;;
    apply)
        apply_cmd
        ;;
    status)
        status_cmd
        ;;
    clear)
        clear_cmd
        ;;
    soft_restart)
        soft_restart_cmd
        ;;
    *)
        usage
        exit 1
        ;;
esac
