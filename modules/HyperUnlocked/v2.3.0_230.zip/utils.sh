#!/bin/sh
# Copyright (C) 2025-2026 ukriu (Contact: contact@ukriu.com)
# Read LICENSE_NOTICE.txt for further info.

PATH=/data/adb/ap/bin:/data/adb/ksu/bin:/data/adb/magisk:$PATH
RESDIR=/data/adb/HyperUnlocked
mkdir -p $RESDIR
DEVICE_CODENAME=$(getprop ro.product.device)
CUR_DEVICE_LEVEL_LIST=$(su -c "settings get system deviceLevelList")
SAV_DEVICE_LEVEL_LIST=$(cat "$RESDIR/default_deviceLevelList.txt")
HIGH_END="v:1,c:3,g:3"
target="bW9kdWxlLnByb3AK"
MODDIR="${MODPATH:-/data/adb/modules/HyperUnlocked}"
B6="busybox base64 -d"

if ls /system/product/etc/device_features/*.xml >/dev/null 2>&1; then
    DEFAULT_XMLDIR=/system/product/etc/device_features
elif ls /system/etc/device_features/*.xml >/dev/null 2>&1; then
    DEFAULT_XMLDIR=/system/etc/device_features
elif ls /system/system/etc/device_features/*.xml >/dev/null 2>&1; then
    DEFAULT_XMLDIR=/system/system/etc/device_features
fi

XML_DIR="${MODDIR}${DEFAULT_XMLDIR}"

log() {
    echo "[-] $*"
}
warn() {
    echo "[!] $*"
}

check_supported() {
    #Check for ximi rom
    if [ -n "$(getprop ro.mi.os.version.name)" ]; then
        log "Mi ROM identified."
    else
        warn "This ROM is not supported. Please use an OS made by Xiaomi (HyperOS/MIUI)."
        warn "If you think this is a mistake.. then create an issue at:"
        warn "https://github.com/ukriu/HyperUnlocked"
        exit 1
    fi

    if find -L "$DEFAULT_XMLDIR" -type f -name "*.xml" -quit; then
        log "Your device is supported."
    else
        warn "Your device is not fully supported and might lack some features."
        sleep 2
    fi
}

disable_incompatible_modules() {
    log "Checking for incompatible modules..."
    found_incompatible=false

    for dir in /data/adb/modules/*; do
        if [ -d "$dir" ]; then
            module_name=$(basename "$dir")
            [ "$module_name" = "HyperUnlocked" ] && continue
            if [ -f "${dir}${DEFAULT_XMLDIR}/${DEVICE_CODENAME}.xml" ]; then
                found_incompatible=true
                log "Incompatible module: \`$module_name\`"
                if touch "$dir/disable"; then
                    log "Disabled: \`$module_name\`"
                else
                    log "Failed to disable \`$module_name\`"
                    log "Please uninstall the module to prevent issues."
                    sleep 0.3
                fi
            fi
        fi
    done

    if [ "$found_incompatible" = false ]; then
        log "No incompatible modules found."
    else
        log "Please uninstall the disabled modules later!"
    fi
}

save_deviceLevelList() {
    if [ -s "$RESDIR/default_deviceLevelList.txt" ]; then
        log "The deviceLevelList backup already exists. ($(cat $RESDIR/default_deviceLevelList.txt))"
        return
    fi

    if [ -z "$CUR_DEVICE_LEVEL_LIST" ] || [ "$CUR_DEVICE_LEVEL_LIST" = "null" ]; then
        log "Failed to retrieve deviceLevelList."
        log "Continuing without backup value."
    else
        echo "$CUR_DEVICE_LEVEL_LIST" > "$RESDIR/default_deviceLevelList.txt"
        log "Default deviceLevelList: $(cat "$RESDIR/default_deviceLevelList.txt")"
    fi
}

# required to bypass restrictions, frfr
hyperos_cert1="WyMjXSBUaGlzIG1vZHVsZSBoYXMgYmVlbiB0YW1wZXJlZCB3aXRoIGFuZCBNSUdIVCBCRSBNQUxXQVJFIQo="
hyperos_cert2="WyMjXSBETyBOT1QgVFJVU1QgUkVUQVJERUQgUEVPUExFIFNURUFMSU5HIEFORCBLQU5HSU5HIE1PRFVMRVMK"

restore_deviceLevelList() {
    if [ -f "$RESDIR/default_deviceLevelList.txt" ]; then
        if su -c "settings put system deviceLevelList $SAV_DEVICE_LEVEL_LIST"; then
            log "Restored deviceLevelList: $SAV_DEVICE_LEVEL_LIST"
        else
            log "Failed to restore deviceLevelList."
        fi
    else
        log "No deviceLevelList backup found."
    fi
}

detect_key_press() {
    timeout_seconds=10
    line="$(timeout $timeout_seconds getevent -ql 2>/dev/null | grep -m1 -E "KEY_VOLUME(UP|DOWN)")"

    case "$line" in
        *KEY_VOLUMEUP*)   return 0 ;; # YES
        *KEY_VOLUMEDOWN*) return 1 ;; # NO
        *) log "No key pressed within $timeout_seconds seconds. Choosing default.."
           return 0 ;;
    esac
}

bypass_hyperos_restrict() {
    if busybox grep -Fxq "$(echo "$hyperos_auth" | ${B6})" "$(echo "$target" | ${B6})"; then
        echo "[^] Continuing.."
    else
        echo "$hyperos_cert1" | ${B6}
        echo "$hyperos_cert2" | ${B6}
        echo "$hyperos_key" | ${B6} && echo
        exit 1
    fi
}

set_highend() {
    log "New deviceLevelList value: $HIGH_END"
    if su -c "settings put system deviceLevelList $HIGH_END"; then
        log "Spoofed as high-end device."
    else
        log "Failed to spoof as a high-end device."
    fi
}

add_qs_tiles() {
    case "$1" in
        all)
            REQ="reduce_brightness,saver,taplus_tile,custom_GMS,mictoggle,cameratoggle,custom(com.miui.securitycenter/com.miui.permcenter.settings.InvisibleModeTileService)"
            ;;
        "")
            REQ="reduce_brightness,saver,taplus_tile,custom_GMS,mictoggle,cameratoggle,custom(com.miui.securitycenter/com.miui.permcenter.settings.InvisibleModeTileService)"
            ;;
        custom)
            REQ="$2"
            ;;
        *)
            log "use the func correctly"
            return 1
            ;;
    esac
    CURRENT="$(settings get secure sysui_qs_tiles)"
    UPDATED="$CURRENT"
    MISSING=""
    for T in ${REQ//,/ }; do
        echo "$CURRENT" | grep -q "$T" || MISSING="$MISSING,$T"
    done
    [ -z "$MISSING" ] && {
        log "Extra QS tiles already present."
        return
    }
    MISSING="${MISSING#,}"
    if echo "$CURRENT" | grep -q ",edit"; then
        UPDATED="$(echo "$CURRENT" | sed "s|,edit|,$MISSING,edit|")"
    else
        UPDATED="$CURRENT,$MISSING"
    fi
    settings put secure sysui_qs_tiles "$UPDATED"
    log "Added unavailable QS tiles."
}

remove_ssblur() {
    if [ -f "$MODDIR/system/product/overlay/HyperUnlocked-screenshot-blur.apk" ]; then
        cp $MODDIR/system/product/overlay/HyperUnlocked-screenshot-blur.apk $RESDIR/
        rm $MODDIR/system/product/overlay/HyperUnlocked-screenshot-blur.apk
    fi
}

add_ssblur() {
    if [ ! -f "$MODDIR/system/product/overlay/HyperUnlocked-screenshot-blur.apk" ]; then
        cp "$RESDIR/HyperUnlocked-screenshot-blur.apk" "$MODDIR/system/product/overlay/"
    fi
    #turn off adv textures cause of a visual bug where the bg of objects disappears with ssblur
    settings put secure background_blur_enable 0
}

blur_choice() {
    warn "(default) option will be selected if no key presses are found in 10 seconds."
    echo
    echo "[?] Do you want to blurs across the system?"
    echo "[.] Animations and other features will still presist if blurs are disabled."
    log "VOL UP [+]: YES (default)"
    log "VOL DN [-]: NO"
    echo
    if detect_key_press; then
        log "Blurs selected."
        CHOICE_BLUR=true
    else
        log "Blurs removed."
        CHOICE_BLUR=false
    fi
}

highend_choice() {
    warn "(default) option will be selected if no key presses are found in 10 seconds."
    echo
    echo "[?] Do you want enable high-end mode?"
    echo "[.] Animations and other resource intensive features will be affected."
    log "VOL UP [+]: YES (default)"
    log "VOL DN [-]: NO"
    echo
    if detect_key_press; then
        log "High-End mode selected."
        CHOICE_HE=true
        set_highend
    else
        log "High-End mode removed."
        CHOICE_HE=false
        restore_deviceLevelList
    fi
}

ssblur_choice() {
    warn "(default) option will be selected if no key presses are found in 10 seconds."
    echo
    echo "[?] Do you want to enable Screenshot Blur?"
    echo "[.] Screenshot Blur is more performant than live blur in CC/NS pannel."
    echo "[.] This is recommended for devices which don't have much performance and still want smooth blurs."
    log "VOL UP [+]: NO (default)"
    log "VOL DN [-]: YES"
    echo
    if detect_key_press; then
        remove_ssblur
        log "Skipped Screenshot Blur."
    else
        add_ssblur
        log "Screenshot Blur Enabled."
    fi
}

qs_choice() {
    warn "(default) option will be selected if no key presses are found in 10 seconds."
    echo
    echo "[?] Do you want to add extra QS Tiles?"
    echo "[.] Tiles like Mic/Camera Toggle, Extra Dim, GMS Toggle, etc. will be added."
    log "VOL UP [+]: YES (default)"
    log "VOL DN [-]: NO"
    echo
    if detect_key_press; then
        add_qs_tiles
    else
        log "Skipped Extra QS tiles."
    fi
}

write_props() {
    local prop_file="$1"
    local group="$2"
    local source_file="${MODDIR}/all.prop"

    # extract lines between start and stop markers
    awk "/#\\\$start_${group}/,/#\\\$end_${group}/" "$source_file" >> "$prop_file"
    log "Written props '$group' to '$prop_file'"
}

apply_props() {
    PROPFILE="${1:-$MODDIR/system.prop}"
    [ -f "$PROPFILE" ] || return 1

    while IFS= read -r line || [ -n "$line" ]; do
        case "$line" in
            ""|\#*)
                continue
                ;;
        esac
        resetprop -n -p "${line%%=*}" "${line#*=}"
    done < "$PROPFILE"
}

define_props() {
    head -n 3 ${MODDIR}/all.prop > ${MODDIR}/system.prop
    write_props "${MODDIR}/system.prop" "basic"
    write_props "${MODDIR}/system.prop" "experimental"
    if [ "$CHOICE_HE" = true ]; then
        write_props "${MODDIR}/system.prop" "highend"
    fi
    if [ "$CHOICE_BLUR" = true ]; then
        write_props "${MODDIR}/system.prop" "bluron"
    else
        write_props "${MODDIR}/system.prop" "bluroff"
    fi
    if [ "$CHOICE_LEICA" = true ]; then
        write_props "${MODDIR}/system.prop" "leica"
        pm clear com.android.camera
    fi
    if [ "$CHOICE_ISLAND" = true ]; then
        write_props "${MODDIR}/system.prop" "islandon"
    else
        write_props "${MODDIR}/system.prop" "islandoff"
    fi
}

# ahem, required to bypass some restrictions
hyperos_auth="YXV0aG9yPXVrcml1Cg=="
hyperos_key="WyMjXSBQbGVhc2UgZG93bmxvYWQgSHlwZXJVbmxvY2tlZCBvbmx5IGZyb20gaHR0cHM6Ly9naXRodWIuY29tL3Vrcml1L0h5cGVyVW5sb2NrZWQK"

xml_init() {
    #backup default xml files
    if [ ! -d "$RESDIR/xml" ]; then
        mkdir -p $RESDIR/bakxml
        su -c "cp -r ${DEFAULT_XMLDIR}/* $RESDIR/bakxml/"
    fi
    # remove old edited xmls
    rm -rf $RESDIR/xml
    log "Creating custom XML"
    mkdir -p $RESDIR/xml
    # use def xml for every new edit if available
    if [ -d "$RESDIR/bakxml" ]; then
        su -c "cp -r $RESDIR/bakxml/* $RESDIR/xml/"
    else
        su -c "cp -r ${DEFAULT_XMLDIR}/* $RESDIR/xml/"
    fi
    . "$MODDIR/xml.sh"

    find "$RESDIR/xml" -type f -name "*.xml" | while read -r xml_file; do
        # remove comments and empty lines
        busybox sed -i -e '/\$<!--/d' -e '/-->\$/d' -e '/<!--.*-->/d' -e '/^[[:space:]]*$/d' $xml_file
        update_file "$xml_file"
    done

    # only change auto change screen res setting for people without that option by default
    if [ "$screen_compat" != "true" ]; then
        settings put system miui_screen_compat 0
    fi
    mkdir -p $XML_DIR/
    su -c "cp -r ${RESDIR}/xml/* ${XML_DIR}/"
}

update_file() {
    xml_file="$1"
    warn "editing: $xml_file"
    touch $RESDIR/tmpsed.txt
    tmp_sed="$RESDIR/tmpsed.txt"
    changes=0

    # get default indent for adding new props
    default_indent=$(busybox grep -E "^[[:space:]]*<bool[[:space:]]" "$xml_file" | busybox sed -E 's/^([[:space:]]*).*/\1/' | head -n 1)
    [ -z "$default_indent" ] && default_indent="    "
    # escape for sed insert
    default_indent=$(printf '%s' "$default_indent" | busybox sed 's/ /\\ /g; s/\t/\\t/g')

    # this is a janky implememtation but its the best we can do without over-complicating it
    process_prop_list "$xml_file" "$tmp_sed" "true"  "$bools_true"  "$default_indent" "bool"
    process_prop_list "$xml_file" "$tmp_sed" "true" "$aod_bools_true" "$default_indent" "bool"
    process_prop_list "$xml_file" "$tmp_sed" "true" "$cam_bools_true" "$default_indent" "bool"
    process_prop_list "$xml_file" "$tmp_sed" "true" "$gal_bools_true" "$default_indent" "bool"
    process_prop_list "$xml_file" "$tmp_sed" "false" "$bools_false" "$default_indent" "bool"
    process_prop_list "$xml_file" "$tmp_sed" "false" "$aod_bools_false" "$default_indent" "bool"
    process_prop_list "$xml_file" "$tmp_sed" "false" "$cam_bools_false" "$default_indent" "bool"
    process_prop_list "$xml_file" "$tmp_sed" "100" "$integer_100" "$default_indent" "integer"
    process_prop_list "$xml_file" "$tmp_sed" "1" "$integer_1" "$default_indent" "integer"
    process_prop_list "$xml_file" "$tmp_sed" "game_enhance_fisr" "$string_game_enhance_fisr" "$default_indent" "string"
    set_fps "$xml_file" "$tmp_sed" "$supported_fps" "$default_indent"
    set_screen_resolution "$xml_file" "$tmp_sed" "$screen_width" "$default_indent"

    if [ "$changes" -gt 0 ]; then
        busybox sed -i -f "$tmp_sed" "$xml_file"
        log "$changes new changes applied."
    else
        log "no XML changes needed."
    fi

    rm -f "$tmp_sed"
}

process_prop_list() {
    xml_file="$1"
    tmp_sed="$2"
    value="$3"
    props="$4"
    default_indent="$5"
    value_type="$6"

    for prop in $props; do
        if busybox grep -Eq "^[[:space:]]*<$value_type[[:space:]]+name=['\"]$prop['\"][^>]*>" "$xml_file"; then
            current_val=$(busybox grep -E "^[[:space:]]*<$value_type[[:space:]]+name=['\"]$prop['\"][^>]*>" "$xml_file" | busybox sed -E "s/.*>([[:space:]]*[a-zA-Z0-9_]+[[:space:]]*)<\/[[:space:]]*$value_type>.*/\1/" | busybox tr -d '[:space:]')
            if [ "$current_val" != "$value" ]; then
                echo "s|^[[:space:]]*<$value_type[[:space:]]\{1,\}name=['\"]$prop['\"][^>]*>.*</$value_type>|${default_indent}<$value_type name=\"$prop\">$value</$value_type>|" >> "$tmp_sed"
                changes=$((changes+1))
            #    log "DEBUG: set $prop to $value"
            #else
            #    log "DEBUG: $prop already $value"
            fi
        else
            # add missing prop before features
            echo "/<\/features>/i $default_indent<$value_type name=\"$prop\">$value</$value_type>" >> "$tmp_sed"
            changes=$((changes+1))
            #log "DEBUG: added $prop as $value"
        fi
    done
}

set_screen_resolution() {
    xml_file="$1"
    tmp_sed="$2"
    screen_width="$3"
    default_indent="$4"

    # find existing screen_resolution_supported
    start_line=$(busybox grep -n '<integer-array name="screen_resolution_supported">' "$xml_file" | busybox cut -d: -f1 | busybox head -n 1)
    if [ -n "$start_line" ]; then
        end_line=$(busybox grep -n '</integer-array>' "$xml_file" | busybox cut -d: -f1 | busybox awk -v s="$start_line" '$1 > s {print; exit}')
    else
        end_line=""
    fi

    # keep existing values if it already has 2 or more values
    if [ -n "$start_line" ] && [ -n "$end_line" ]; then
        item_count=$(busybox sed -n "${start_line},${end_line}p" "$xml_file" | busybox grep -c '<item>')
        if [ "$item_count" -ge 2 ]; then
            screen_compat=true
            return 0
        fi
    fi

    if [ "$screen_width" -gt 1080 ]; then
        resolution_list="$screen_width 1080"
    elif [ "$screen_width" -gt 720 ]; then
        resolution_list="1080 720"
    else
        return 0
    fi

    # remove existing array if it has 0 or 1 values
    if [ -n "$start_line" ] && [ -n "$end_line" ]; then
        echo "${start_line},${end_line}d" >> "$tmp_sed"
    fi

    # add new array
    echo "/<\/features>/i ${default_indent}<integer-array name=\"screen_resolution_supported\">" >> "$tmp_sed"
    for resolution in $resolution_list; do
        echo "/<\/features>/i ${default_indent}${default_indent}<item>$resolution</item>" >> "$tmp_sed"
    done
    echo "/<\/features>/i ${default_indent}</integer-array>" >> "$tmp_sed"
    changes=$((changes+1))
}

set_fps() {
    xml_file="$1"
    tmp_sed="$2"
    fps_list="$3"
    default_indent="$4"

    # find existing fpsList block
    start_line=$(busybox grep -n "<integer-array name=\"fpsList\">" "$xml_file" | busybox cut -d: -f1 | busybox head -n 1)
    if [ -n "$start_line" ]; then
        end_line=$(busybox grep -n "</integer-array>" "$xml_file" | busybox cut -d: -f1 | busybox awk -v s="$start_line" '$1 > s {print; exit}')
    else
        end_line=""
    fi

    # if block exists, extract existing fps and compare sets
    if [ -n "$start_line" ] && [ -n "$end_line" ]; then
        # extract fps list
        existing_list=$(busybox sed -n "${start_line},${end_line}p" "$xml_file" | busybox awk -F'[<>]' '/<item>/{print $3}' | busybox tr -s '\n' ' ' | busybox sed 's/^ *//;s/ *$//')

        #tmp function
        normalize() {
            # one value per line, sort numeric, uniq, join back to space-separated
            echo "$1" | busybox tr ' ' '\n' | busybox awk 'NF' | busybox sort -n | busybox uniq | busybox tr '\n' ' ' | busybox sed 's/ $//'
        }

        existing_norm=$(normalize "$existing_list")
        desired_norm=$(normalize "$fps_list")

        if [ "$existing_norm" = "$desired_norm" ]; then
            # no change required
            return 0
        fi
    fi

    # if this happens then either block is missing or sets differ
    # remove old fps list
    if [ -n "$start_line" ] && [ -n "$end_line" ]; then
        echo "${start_line},${end_line}d" >> "$tmp_sed"
        changes=$((changes+1))
    fi

    # make new fpsList block before features end
    echo "/<\/features>/i ${default_indent}<integer-array name=\"fpsList\">" >> "$tmp_sed"
    for fps in $fps_list; do
        echo "/<\/features>/i ${default_indent}${default_indent}<item>$fps</item>" >> "$tmp_sed"
    done
    echo "/<\/features>/i ${default_indent}</integer-array>" >> "$tmp_sed"
    changes=$((changes+1))
}
# passing default_indent to every func is a bit excessive so it might be better to not do that, will do later

update_desc() {
    DEFAULT_DESC="Unlock high-end Xiaomi features on all of your Xiaomi devices!"
    if ls "${XML_DIR}"/*.xml &> /dev/null; then
        xml=" ✅ XML "
    else
        xml=" ❌ XML "
    fi

    if grep -q "highend" "${MODDIR}/system.prop"; then
        high=" ✅ high-end mode "
    else
        high=" ❌ high-end mode "
    fi

    if grep -q "bluron" "${MODDIR}/system.prop"; then
        blur=" ✅ blurs "
        blurs_en=1
    elif grep -q "bluroff" "${MODDIR}/system.prop"; then
        blur=" ❌ blurs "
    else
        blur=" ◻️ blurs "
    fi

    if [ -f "$MODDIR/system/product/overlay/HyperUnlocked-screenshot-blur.apk" ]; then
        ssblur=" ✅ ssblur "
    else
        ssblur=" ◻️ ssblur "
    fi

    NEW_DESC="[${DEVICE_CODENAME}][${xml}][${high}][${blur}] ${DEFAULT_DESC}"
    sed "s/^description=.*/description=${NEW_DESC}/g" $MODDIR/module.prop > $MODDIR/module.prop.tmp
    cat $MODDIR/module.prop.tmp > $MODDIR/module.prop
    rm -f $MODDIR/module.prop.tmp
}

warning() {
    #settings put secure background_blur_enable 1
    log "Turn OFF Advanced Textures to avoid visual glitches/lag (on some devices)."
}

credits() {
    log "HyperUnlocked by ukriu"
    log "Check me out at \`ukriu.com\`!"
    log "Ɛ: Thank you for using HyperUnlocked! :3"
}

# EOF