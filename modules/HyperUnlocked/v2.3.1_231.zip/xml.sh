#!/bin/sh
# Copyright (C) 2025-2026 ukriu (Contact: contact@ukriu.com)
# Read LICENSE_NOTICE.txt for further info.

supported_fps="$(dumpsys display | grep -oE "fps=[0-9.]+" | cut -d= -f2 | awk -F. '{print $1}' | sort -nu | xargs)"
screen_width="$(wm size | sed -n 's/Physical size: \([0-9]*\)x.*/\1/p')"

cam_bools_true="
camera_adjust_picture_size_enabled
camera_is_support_portrait_front
camera_is_support_portrait_switch
camera_support_ai_lens
camera_supported_scene
config_camera_refresh_rate_policy
is_camera_app_water_mark
is_camera_lower_qrscan_frequency
is_full_size_effect
is_support_portrait
support_3d_face_beauty
support_auto_mirror
support_camera_4k_quality
support_camera_age_detection
support_camera_aohdr
support_camera_audio_focus
support_camera_boost_brightness
support_camera_burst_shoot
support_camera_burst_shoot_denoise
support_camera_dynamic_light_spot
support_camera_face_info_water_mark
support_camera_gradienter
support_camera_groupshot
support_camera_hfr
support_camera_magic_mirror
support_camera_manual_function
support_camera_manual_function_et
support_camera_manual_function_focus
support_camera_movie_solid
support_camera_new_style_time_water_mark
support_camera_peaking_mf
support_camera_press_down_capture
support_camera_quick_snap
support_camera_record_location
support_camera_satellite
support_camera_shader_effect
support_camera_skin_beauty
support_camera_square_mode
support_camera_tilt_shift
support_camera_torch_capture
support_camera_video_face_detection
support_camera_video_pause
support_camera_water_mark
support_chroma_flash
support_front_hdr
support_front_hht
support_front_hht_enhance
support_hd_record_param
support_nature_mode
support_realtime_manual_exposure_time
support_screen_effect
support_screen_light
support_video_hfr_mode
by_ukriu
"

cam_bools_false="
is_camera_face_detection_need_orientation
is_camera_freeze_after_hdr_capture
is_camera_hold_blur_background
is_camera_isp_rotated
is_camera_replace_higher_cost_effect
is_lower_size_effect
is_lower_size_panorama
"

gal_bools_true="
gallery_support_analytic_face_and_scene
gallery_support_dolby
gallery_support_media_feature
gallery_support_print
gallery_support_time_burst_video
gallery_support_video_compress
support_gallery_hdr
support_local_ocr
"

bools_true="
btdebug_enabled
config_sunlight_mode_available
enable_flash_global
enable_miui_lite
enhance_beauty_with_hht
is_compatible_paper_and_screen_effect
is_default_temporary_style
is_support_partial_screenshot
is_support_video_tool_box
is_xiaomi
is_xiaomi_device
support_24bit_record
support_AI_display
support_android_flashlight
support_app_hiding
support_ar_core
support_audio_loopback
support_audio_share
support_autobrightness_by_application_category
support_autobrightness_optimize
support_bluetooth_cloud_data
support_cit
support_cloud_dim
support_conversation_toolbox_voiprecord
support_credentials
support_dark_mode_notify
support_decrease_brightness_spec_app
support_display_expert_mode
support_displayfeature_gamemode
support_displayfeature_gamemode_HDR
support_dolby
support_dolby_version_brighten
support_erase_external_storage
support_feedback_level
support_fm
support_front_beauty_mfnr
support_front_bokeh
support_front_flash
support_full_size_panorama
support_game_dim
support_game_gunsight
support_game_mi_time
support_gesture_wakeup
support_hangup_while_screen_off
support_hdr_enhance
support_hdr_hbm_brighten
support_headset
support_hfr_video_pause
support_hide_discoverable
support_hifi
support_high_resolution
support_idle_dim
support_interview_record_param
support_lhdc_offload
support_low_power_mode_decrease_brightness
support_main_xiaoai
support_manual_brightness_boost
support_manual_dimming
support_media_feedback
support_mi_game_macro
support_miplay_cast_privacy
support_my_device
support_new_silentmode
support_object_track
support_oldman_mode
support_page_layout
support_paper_eyecare
support_papermode_animation
support_parental_control
support_phone_call_noise_suppression
support_picture_watermark
support_power_mode
support_power_save_new
support_provision_app_permission
support_record_param
support_screen_color_persist
support_screen_enhance_engine
support_screen_on_delayed
support_screen_optimize
support_screen_paper_mode
support_show_basic_items
support_smart_fps
support_sound_assist
support_steps_provider
support_stereo_record
support_super_resolution
support_tap_fingerprint_sensor_to_home
support_torch
support_touch_sensitive
support_touchfeature_gamemode
support_true_color
support_truetone
support_ui_orientation_v2
support_videobox_cinema_adapt_ce
support_videobox_display_effect
support_voip_record
support_wild_boost
support_wild_boost_bat_perf
"

bools_false="
is_hongmi
"
aod_bools_true="
aod_support_keycode_goto_dismiss
is_video_screen
support_aod
support_aod_aon
support_aod_fullscreen
"
aod_bools_false="
is_only_support_keycode_goto
"
nfc_related_bools_true="
support_nfc
support_se_route
"
integer_100="burst_shoot_count"
integer_1="support_inner_record support_widevine_l1"
string_game_enhance_fisr="game_enhance_feature_name"

# remove full screen aod for hos3 since it bootloops on some devices.
supported="gold houji peridot"
case "$(getprop ro.build.fingerprint)" in
  Xiaomi/*/*:*/*/OS3.*:user/release-keys | \
  Redmi/*/*:*/*/OS3.*:user/release-keys | \
  POCO/*/*:*/*/OS3.*:user/release-keys)
    sup=0
    for s in $supported; do
      if [ "$(getprop ro.product.device)" = "$s" ]; then
        sup=1
        break
      fi
    done
    if [ "$sup" = "0" ]; then
      aod_bools_true="$(printf '%s\n' "$aod_bools_true" | awk '$0 != "support_aod_fullscreen"')"
      echo "[-] Device is in HyperOS 3. Full Screen AOD support will not be changed temporarily."
    fi
    ;;
  *)
    # nothing
    ;;
esac

