const t={reboot_to_apply:"Khởi động lại thiết bị để áp dụng các thay đổi.",has_shortcut:"Lối tắt đã tồn tại."},o={toast:t};export{o as default,t as toast};
