#!/system/bin/sh

until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 2
done

sleep 5
chmod 0644 data/adb/modules/COPG/COPG.json
chcon u:object_r:system_file:s0 /data/adb/modules/COPG/COPG.json

# licensing: the GPU license-verify verdict is memoized IN THE COMPANION PROCESS (in memory),
# not on disk — a disk cache in /data/adb is forgeable by root and would unlock GPU with no
# license. So there is nothing to warm here; the first gpu-app launch per boot pays the verify,
# the rest are instant. Remove any stale disk cache left by older builds.
rm -f /data/adb/modules/COPG/.lic_cache 2>/dev/null

exec /data/adb/modules/COPG/controller >/dev/null 2>&1 &
