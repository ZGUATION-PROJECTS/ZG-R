"Added terminal support:
•Run `vid2boot` in the terminal to create flashable bootanimation modules.
•Run `boot2vid` to convert bootanimation.zip into MP4 videos.

You can now change the value in customize.sh#L15 to 0 to skip bootanimation creation during installation. You can create bootanimations later using Terminal."
