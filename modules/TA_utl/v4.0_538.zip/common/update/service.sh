MODPATH=${0%/*}

rm -rf "$MODPATH"